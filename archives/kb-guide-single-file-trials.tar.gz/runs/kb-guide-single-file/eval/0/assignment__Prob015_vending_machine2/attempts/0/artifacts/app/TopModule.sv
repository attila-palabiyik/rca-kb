module TopModule(
    input wire clk,
    input wire rst,
    input wire d1,
    input wire d2,
    input wire sel,

    output reg out1,
    output reg out2,
    output reg out3
);

    reg [1:0] sampled_coins;
    reg [1:0] previous_coins;
    wire [1:0] coin_edges = {d2, d1} & ~previous_coins;

    // The rising edge captures the inputs. The falling edge ends each pulse
    // and saves the sample for comparison at the next rising edge.
    wire d1_pulse = sampled_coins[0] & ~previous_coins[0];
    wire d2_pulse = sampled_coins[1] & ~previous_coins[1];

    always @(negedge clk or negedge rst) begin
        if (!rst)
            previous_coins <= 2'b00;
        else
            previous_coins <= sampled_coins;
    end

    // Amounts are in half-yuan units. The balance before a sale is at most four.
    reg [2:0] balance;
    wire [2:0] inserted = {1'b0, coin_edges[1], 1'b0}
                        + {2'b00, coin_edges[0]};
    wire [2:0] total = balance + inserted;
    wire [2:0] price = sel ? 3'd5 : 3'd3;
    wire vend = total >= price;

    reg [2:0] pending_change;
    wire [3:0] change_due = {1'b0, pending_change}
                          + (vend ? {1'b0, total} - {1'b0, price} : 4'd0);

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            sampled_coins <= 2'b00;
            balance <= 3'd0;
            pending_change <= 3'd0;
            out1 <= 1'b0;
            out2 <= 1'b0;
            out3 <= 1'b0;
        end else begin
            sampled_coins <= {d2, d1};
            balance <= vend ? 3'd0 : total;
            out1 <= vend && !sel;
            out2 <= vend && sel;
            out3 <= change_due != 4'd0;

            if (change_due != 4'd0)
                pending_change <= change_due - 4'd1;
        end
    end

endmodule
