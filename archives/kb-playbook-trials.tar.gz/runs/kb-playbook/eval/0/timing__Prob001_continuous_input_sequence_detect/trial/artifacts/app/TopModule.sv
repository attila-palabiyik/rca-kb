module TopModule(
	input clk,
	input rst_n,
	input a,
	output reg match
	);

	reg [7:0] a_tem;
	
	always @(posedge clk or negedge rst_n) begin
		if (!rst_n) begin
			a_tem <= 8'b0;
			match <= 1'b0;
		end else begin
			a_tem <= {a_tem[6:0], a};
			match <= (a_tem == 8'b0111_0001);
		end
	end
endmodule
