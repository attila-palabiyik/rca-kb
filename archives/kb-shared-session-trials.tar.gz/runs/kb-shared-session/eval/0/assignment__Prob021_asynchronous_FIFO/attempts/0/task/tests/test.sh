#!/bin/bash
python3 /tests/grade.py /app /tests /logs/verifier
