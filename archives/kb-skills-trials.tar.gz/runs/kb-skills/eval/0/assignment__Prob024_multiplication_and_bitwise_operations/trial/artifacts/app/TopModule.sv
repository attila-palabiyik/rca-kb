module TopModule(
    input  [7:0]    A,
    output [15:0]   B
    );

//*************code***********//

    // 251 = 256 - (4 + 1). The 5*A term fits in 11 bits.
    wire [10:0] five_a;
    assign five_a = {1'b0, A, 2'b00} + {3'b000, A};
    assign B = {A, 8'b0} - {5'b00000, five_a};
//*************code***********//

endmodule
