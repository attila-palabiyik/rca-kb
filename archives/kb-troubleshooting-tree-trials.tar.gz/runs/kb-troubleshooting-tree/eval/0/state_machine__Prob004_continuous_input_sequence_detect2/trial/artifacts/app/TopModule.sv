module TopModule(
	input clk,
	input rst_n,
	input data,
	input data_valid,
	output reg match
	);


reg [3:0] pstate,nstate;

parameter idle=4'd0,
		  s1_d0=4'd1,
          s2_d01=4'd2,
          s3_d011=4'd3,
          s4_d0110=4'd4;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        pstate<=idle;
    else
        pstate<=nstate;
end

always @(pstate or data or data_valid)
begin
    case(pstate)
        idle:
            if(data_valid && !data)
                nstate=s1_d0;			//First bit matched
            else
                nstate=idle;
        s1_d0:
            if (data_valid)
				begin	
					if (data) nstate = s2_d01;		//Data valid and is 1, first two bits 01 matched, next state is s2_d01
					else nstate = s1_d0;			//Data valid but is 0, only first bit 0 matched, next state is s1_d0
				end
			else nstate = s1_d0;					//Data invalid, stay in s1_d0
        s2_d01:
            if (data_valid)
				begin	
					if (data) nstate = s3_d011;		//Data valid and is 1, first three bits 011 matched, next state is s3_d011
					else nstate = s1_d0;			//Data valid but is 0, only first bit 0 matched, next state is s1_d0
				end
			else nstate = s2_d01;					//Data invalid, stay in s2_d01
        s3_d011:
            if (data_valid)
				begin	
					if (!data) nstate = s4_d0110;		//Data valid and is 0, first four bits 0110 matched, next state is s4_d0110
					else nstate = idle;					//Data valid but is 1, no match, next state is idle
				end
			else nstate = s3_d011;					//Data invalid, stay in s3_d011
        s4_d0110:
            if (data_valid)
				begin	
					if (!data) nstate = s1_d0;		//Data valid and is 0, matches first bit 0 of target sequence, next state is s1_d0
					else nstate = s2_d01;			//The final 0 and the new 1 form the prefix 01
				end
			else nstate = s1_d0;					//End the match pulse and retain the final 0
        default:
            nstate=idle;
        endcase
end

always @(pstate or rst_n)
begin
    if(!rst_n)
        match=1'b0;
    else if(pstate==s4_d0110)						//Entering state s4_d0110 means all four bits matched, assert match signal high
            match=1'b1;
         else
            match=1'b0;
end

endmodule
